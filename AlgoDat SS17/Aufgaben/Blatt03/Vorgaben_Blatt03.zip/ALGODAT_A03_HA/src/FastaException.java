public class FastaException extends Exception {
}

