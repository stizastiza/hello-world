import java.io.IOException;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;

public class FastaParser {
	/**
	 * Parse Fasta File and return list of sequences
	 * @param file to read
	 * @return ArrayList of String Objects containing the sequences
	 */
	public ArrayList<String> readSequences(File file) throws FastaException, IOException {
	    //RandomAccessFile input = null;

	    //input = new RandomAccessFile(file, "r");
	    //String line;
	    //while ((line = input.readLine()) != null) { // read file line by line, if line == null, end is reached
	    	// Process line
	    //}
	    return null;
	}

	/**
	 * Runs readSequence on the input and returns either a string presentation of the resulting ArrayList or, 
         * in case of an Exception, the corresponding message (hint: Exceptions are normal objects with fields/ methods) 
	 * @param file to read
	 * @return String representation of result list or exception message
	 */
	public String handleException(File f) {

	    return null;
	}

}

