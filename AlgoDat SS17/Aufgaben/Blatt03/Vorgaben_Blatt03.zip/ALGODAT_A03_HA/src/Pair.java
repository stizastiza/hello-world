
public class Pair<T> {
	Pair(T first, T second) {
		// TODO
	}

	public T getFirst() {
		// TODO
		return null;
	}

	public T getSecond() {
		// TODO
		return null;
	}

	public void setFirst(T dt) {
		// TODO
	}

	public void setSecond(T dt) {
		// TODO
	}

	public void swap() {
		// TODO
	}

	@Override
	public String toString() {
		// TODO
		return "";
	}
}

