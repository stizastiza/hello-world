import java.util.ArrayList;
import java.util.Collections;

/**
 * This class implements two methods. These check an array on a few
 * characteristics.
 * 
 * @author AlgoDat-Tutoren
 * 
 */
public class ArrayCheck {

	/**
	 * Tests all elements of the given array, if they are divisible by the given
	 * divisor.
	 * 
	 * @param arr
	 *            array to be tested
	 * @param divisor
	 *            number by which all elements of the given array should be
	 *            divisible
	 * @return true if all elements are divisible by divisor
	 */
	public boolean allDivisibleBy(ArrayList<Integer> arr, int divisor) {
        // TODO
        return true;
    }

	/**
	 * Tests if the given two arrays are anagrams of each other
	 * 
	 * @param arr1
	 *            first array to be compared
	 * @param arr2
	 *            second array to be compared
	 * @return true if the two arrays are an anagram
	 */
    public boolean isAnagram(ArrayList<Character> arr1, ArrayList<Character> arr2) {
        // TODO
        return true;
    }

}

