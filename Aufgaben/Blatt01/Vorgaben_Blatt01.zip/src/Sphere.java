class Sphere {
	
	Point center;
	double radius;
	
	Sphere(int x, int y, int z, double r){
		// TODO
	}
	
	Sphere(Point c, double r){
		// TODO
	}
	
	int getX(){
		return -1; // TODO
	}

	int getY(){
		return -1; // TODO
	}

	int getZ(){
		return -1; // TODO
	}


	double getRadius(){
		return -1; // TODO
	}

	double calculateDiameter(){
		return -1; // TODO
	}	
	
	double calculateSurfaceArea(){
		return -1; // TODO
	}
	
	double calculateVolume(){
		return -1; // TODO
	}

}

