/**
 * Represents a Cube
 * @author AlgoDat
 */
public class Cube {

	/*
	 * Constructor without parameter
	 */
	public Cube() {
		//TODO
	}
	/*
	 * Constructor with one parameter
	 * 
	 * @param length the side length of the cube
	 */
	public Cube(double length) {
		// TODO
	}

	public double getLength(){
		return this.length;
	}
	//TODO: ggf. weitere Methoden und member implementieren
}

