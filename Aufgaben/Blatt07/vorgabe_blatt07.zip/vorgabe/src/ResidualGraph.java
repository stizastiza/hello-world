import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Stack;

/**
 * @author Arne
 * 
 */
public class ResidualGraph extends DiGraph {

	// -- constructor --
	public ResidualGraph() {
	}
	
	/**
	 * Finds an augmenting path from start to end in the graph A path is
	 * augmenting if all it's edges have residual capacity > 0 (You can choose
	 * from several algorithms to find a path)
	 * 
	 * @param startNodeId
	 *            the id of the start node from where we should start the search
	 * @param endNodeId
	 *            the id of the end node which we want to reach
	 * 
	 * @return the path from start to end or an empty list if there is none
	 */
	public LinkedList<Node> findAugmentingPath(int startNodeId, int endNodeId) {
		// TODO: Your implementation here
		return new LinkedList<Node>();
	}

	/**
	 * Finds the minimal residual capacity over the given path
	 * 
	 * @return the minimal capacity
	 */
	public double findMinCapacity(LinkedList<Node> path) {
		// TODO: Your implementation here
		return -1;
	}

	/**
	 * Update capacity on given path, to be executed on residual graph
	 */
	public void updateResidualCapacity(double minCapacity, LinkedList<Node> path) {
		// TODO: Your implementation here
	}

}

